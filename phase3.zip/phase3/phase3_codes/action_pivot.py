###################################################################################################
# Group number : wed_10_5 
# Group member : Tessa(Hyeri) Song, Martin, Yash
# This cgi script was designed to build pivot tables from specific weather datasets
#     getting options from user.
# If a user put invalid inputs, it leads the user to a webpage with a proper error message.
#
###################################################################################################

import cgi
import sys
import cgitb
import csv
from util import (city_list, year_list) 

cgitb.enable()
sys.stderr = sys.stdout    

# print XHTML header with title
def xhtml_head(title):
    print '''
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
%s
<link rel="stylesheet" href="css_file/aggregation.css" type="text/css" media="screen" charset="utf-8" />
<link rel="stylesheet" href="css_file/pivot_page.css" type="text/css" media="screen" charset="utf-8" />
</head><body>
''' % title

html_end = '</body></html>'

# get the inputs from user
def get_user_input():
    form = cgi.FieldStorage()
    
    row = form.getfirst('row')
    column = form.getfirst('column')
    value = form.getfirst('value')
    
    filter = form.getfirst('filter')
    filter_value = form.getlist('filter_value')
    
    return row, column, value, filter, filter_value

def link_to_first_page():
    print '<p><a href="%s">Click here to return to the input form</a></p>' % 'display_explanation.py'

def error_page(msg):
    print '<p>%s</p>' % msg
    link_to_first_page()
    print html_end

# generate html page
def gen_html():
    row, column, value, filter, filter_value = get_user_input()
    
    print 'Content-Type: text/html\n'    
    
    # deal with wrong inputs
    if row == column:
        xhtml_head('<title>Wrong Inputs</title>')        
        error_page('Row and column should be different to each other.') 
    elif filter == 'city' and len(filter_value) != 0:
        if (filter_value[0] not in city_list):
            xhtml_head('<title>Wrong Inputs</title>')
            error_page('City should be one of the given list.')
        else:
            show_pivot(row, column, value, filter, filter_value)
    elif filter == 'year' and len(filter_value) != 0:
        try:
            value = int(filter_value[0])
        except ValueError:
            xhtml_head('<title>Wrong Inputs</title>')
            error_page('Characters are not allowed at this option.')
            return
        if value not in range(1980,2013):
                xhtml_head('<title>Wrong Inputs</title>')
                error_page('Year should be from 1980 to 2012.')
        else:
            show_pivot(row, column, value, filter, filter_value)
    else:
        show_pivot(row, column, value, filter, filter_value)

# show the required pivot table        
def show_pivot(row, column, value, filter, filter_value):
    xhtml_head('<title>The required pivot</title>')
    print '<h1>This is the built pivot table by your options</h1>'
    gen_pivot_table(row, column, value, filter, filter_value)
    print html_end        
        
# generate the pivot table    
def gen_pivot_table(row, column, value, filter, filter_value):
    data_list = []

    # open the 6 csv files in order
    for csvfile in city_list:
        fopen = open('csv_file/'+csvfile+'.csv','r')
        data_list.append(list(csv.reader(fopen)))
    
    year_flag = False
    city_flag = False
    
    if filter == 'year':
        if len(filter_value)!= 0:
            year_flag = True
    else:
        if len(filter_value)!= 0:
            city_flag = True
    
    print '<table>'
    
    if row == 'year':
        if_row_is_year(data_list, value, filter_value, year_flag, city_flag)    
    
    else:
        if_row_is_city(data_list, value, filter_value, year_flag, city_flag)

    print '</table>'

       
def if_row_is_city(data_list, value, filter_value, year_flag, city_flag):
    if(city_flag):
        print '<tr><th></th>'
        print '<th>%s</th></tr>' % filter_value[0]
        
        city_index = city_list.index(filter_value[0])
        
        for year in year_list:
            print '<tr><th>%s</th>' % year
            if value == 'Rainfall':
                rain_cell(data_list[city_index][year-1979][2])
            elif value == 'Temperature':
                temp_cell(data_list[city_index][year-1979][3])
            else:
                solar_cell(data_list[city_index][year-1979][4])
            print '</tr>'
            
    elif(year_flag):
        print '<tr><th></th>'
        for city in city_list:
            print '<th>%s</th>' % city
        print '</tr>'
        
        year_index = year_list.index(int(filter_value[0]))
        
        print '<tr><th>%s</th>' % filter_value[0]
        for data in data_list:    
            if value == 'Rainfall':
                rain_cell(data[year_index+1][2])
            elif value == 'Temperature':
                temp_cell(data[year_index+1][3])
            else:
                solar_cell(data[year_index+1][4])
        print '</tr>'
        
    else:
        print '<tr><th></th>'
        for city in city_list:
            print '<th>%s</th>' % city
        print '</tr>'
    
        for year in year_list:
            print '<tr><th>%s</th>' % year
            for data in data_list:
                if value == 'Rainfall':
                    rain_cell(data[year-1979][2])
                elif value == 'Temperature':
                    temp_cell(data[year-1979][3])
                else:
                    solar_cell(data[year-1979][4])
            print '</tr>'
            
            
def if_row_is_year(data_list, value, filter_value, year_flag, city_flag):
    if (city_flag):
        print '<tr><th></th>'
        for year in year_list:
            print '<th>%s</th>' % year
        print '</tr>'
        
        city_index = city_list.index(filter_value[0])
        
        print '<tr><th>%s</th>' % filter_value[0]
        
        for year in year_list:
            if value == 'Rainfall':
                rain_cell(data_list[city_index][year-1979][2])
            elif value == 'Temperature':
                temp_cell(data_list[city_index][year-1979][3])
            else:
                solar_cell(data_list[city_index][year-1979][4])
        print '</tr>'  
    
    elif(year_flag):
        print '<tr><th></th><th>%s</th></tr>' % filter_value[0]
        
        year_index = year_list.index(int(filter_value[0]))
        
        for data in data_list:
            print '<tr><th>%s</th>' %data[1][0]
            if value == 'Rainfall':
                rain_cell(data[year_index+1][2])
            elif value == 'Temperature':
                temp_cell(data[year_index+1][3])
            else:
                solar_cell(data[year_index+1][4])
        print '</tr>'

    else:
        print '<tr><th></th>'
        for year in year_list:
            print '<th>%s</th>' % year
        print '</tr>'
        
        for data in data_list:
            if value == 'Rainfall':
                print_value(data,2)
            elif value == 'Temperature':
                print_value(data,3)
            else :
                print_value(data,4)
    
    
def print_value(data, col):
    print '<tr><th>%s</th>' % data[1][0]
    for i in range(1,34):
        if col == 2:
            rain_cell(data[i][col])
        elif col == 3:
            temp_cell(data[i][col])
        else:
            solar_cell(data[i][col])
    print '</tr>'

    
def rain_cell(value):
    print '<td',
    print 'class = "%s"' % color_rain(value),
    print '>%s</td>' % value
    
def temp_cell(value):
    print '<td',
    print 'class = "%s"' % color_temp(value),
    print '>%s</td>' % value
    
def solar_cell(value):
    print '<td',
    print 'class = "%s"' % color_solar(value),
    print '>%s</td>' % value

    
def color_temp(temp):
    temp = float(temp)
    if 18 <= temp < 19.75:
        return 'temp1'
    elif 19.75 <= temp < 21.5:
        return 'temp2'
    elif 21.5 <= temp < 23.25:
        return 'temp3' 
    elif 23.25 <= temp < 25:
        return 'temp4'
    elif 25 <= temp < 26.75:
        return 'temp5'
    elif 26.75 <= temp < 28.5:
        return 'temp6'
    elif 28.5<= temp < 30.25:
        return 'temp7'
    elif 30.25 <= temp < 32:
        return 'temp8'
    else:
        return 'temp9'   
        
def color_solar(solar):
    if solar == 'N/A':
        return
    solar = float(solar)
    if 14 <= solar < 15.5:
        return 'solar1'
    elif 15.5 <= solar < 17:
        return 'solar2'
    elif 17 <= solar < 18.5:
        return 'solar3' 
    elif 18.5 <= solar < 20:
        return 'solar4'
    elif 20 <= solar < 21.5:
        return 'solar5'
    else:
        return 'solar6'    
        
def color_rain(rain):
    rain = float(rain)
    if 214 <= rain < 501:
        return 'rain1'
    elif 501 <= rain < 788:
        return 'rain2'
    elif 788 <= rain < 1075:
        return 'rain3' 
    elif 1075 <= rain < 1362:
        return 'rain4'
    elif 1362 <= rain < 1649:
        return 'rain5'
    elif 1649 <= rain < 1936:
        return 'rain6'
    elif 1936 <= rain < 2223:
        return 'rain7' 
    elif 2223 <= rain < 2510:
        return 'rain8'
    else:
        return 'rain9'        
    
# calling main function
gen_html()





















