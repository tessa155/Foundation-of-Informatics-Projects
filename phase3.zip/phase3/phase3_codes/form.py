import cgitb; cgitb.enable()

action_uri = "action_pivot.py"

def display_form():
    # we have to use get at the moment, because post is not working on IVLE
    print '<form method="get" action="%s">' % action_uri
    
    print '<p>Rows'
    print '<select name="row">'
    print '<option value="year">Year</option>'
    print '<option value="city" selected="selected">City</option>'
    print '</select>'
    print '</p>'
    
    print '<p>Columns'
    print '<select name="column">'
    print '<option value="city">City</option>'
    print '<option value="year" selected="selected">Year</option>'
    print '</select>'
    print '</p>'


    print '<p>Value'
    print '<select name="value">'
    print '<option value="Solar_exposure">Solar exposure</option>'
    print '<option value="Rainfall">Rainfall</option>'
    print '<option value="Temperature" selected="selected">Temperature</option>'
    print '</select>'
    print '</p>'
    
    print '<p>Filter'
    print '<select name="filter">'
    print '<option value="city">City</option>'
    print '<option value="year" selected="selected">Year</option>'
    print '</select>'
    print '<input type="text" name="filter_value" />'
    print '</p>'    

    # Place submit and reset buttons at the bottom of the form.
    print '<p> <input type="submit" /> <input type="reset" /> </p>'
    print '</form>'
    
    
    
    
    