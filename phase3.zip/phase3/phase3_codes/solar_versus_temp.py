import os, sys
os.dup2(2,3)
stderr = os.fdopen(2,'a')
stderr.close()
import matplotlib
matplotlib.use('Agg')
from pylab import *
os.dup2(3,2)
sys.__stderr__ = sys.stderr = os.fdopen(2,'a')

import urllib
import csv
import cgi
from util import (city_list, year_list)

def open_files():
    data_list = []

    for csvfile in city_list:
        fopen = open('csv_file/'+csvfile+'.csv','r')
        data_list.append(list(csv.reader(fopen)))
    return data_list

def extract_info(data_list, column):
    info_list = []
    
    for data in data_list:
        info = []
        for i in range(11,26):
            info.append(data[i][column])
        info_list.append(info)

    return info_list    
    

def main():
    
    data_list = open_files()
    temp_list = extract_info(data_list, 3)
    solar_list = extract_info(data_list, 4)
    
    clf()
    i = 0
    for temp in temp_list:
        plot(temp,solar_list[i], "o")
        i +=1

    legend(city_list,loc='lower right', numpoints=1)    
    ylabel("solar")
    xlabel("temp")
    
    title("Relationship between solar and temp of 6 cities(1990 - 2004)")
    webshow("solar_temp.png")


def webshow( img ):
    savefig( img, dpi=70 )
    print 'Content-Type: text/html\n'
    print '<img width="500" height="400" src="'+img+'" />'
    
main()

