from form import display_form
import cgitb; cgitb.enable()

def xhtml_chunk(title):
    print '''
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" id="display_form">
<head><meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<title>%s</title>
<link rel="stylesheet" href="css_file/decoration.css" type="text/css" media="screen" charset="utf-8" />
</head><body>
''' % title    

def display_page():
    xhtml_chunk('Pivot Table')
    display_body()
    print '</html>'

    
def display_body():
    print '<div id="pivot_1">'
    print '<h1>Please choose the option you want</h1>'
    display_form()
    print '</div>'
    print '<br />'
    print '<div id="instruction">'
    print '<p>The range of year is from 1980 - 2012</p>'
    print '<p>The cities are:</p>'
    print '<ul><li>Melbourne</li>'
    print '<li>Sydney</li>'
    print '<li>Cairns</li>'
    print '<li>Adelaide</li>'
    print '<li>Perth</li>'
    print '<li>Darwin</li>'
    print '</ul></div>'
    print '<h2><a href="display_explanation.py">Please click here to return to the previous page</a></h2>'  
    print '</body>'
    
def main ():
    print 'Content-Type: text/html\n'
    display_page()
    
main() 
