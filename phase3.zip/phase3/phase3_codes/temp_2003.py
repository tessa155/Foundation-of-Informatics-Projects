import os, sys
os.dup2(2,3)
stderr = os.fdopen(2,'a')
stderr.close()
import matplotlib
matplotlib.use('Agg')
from pylab import *
os.dup2(3,2)
sys.__stderr__ = sys.stderr = os.fdopen(2,'a')

import csv
import cgi
from util import (city_list, month_list)

def main():
    fopen = open("csv_file/temp_2003.csv", 'r')
    data = list(csv.reader(fopen))

    clf()

    for line in data[1:]:
        plot (line[1:], linewidth=2) 
    
    legend(city_list, loc='lower right', numpoints=40,
        prop=matplotlib.font_manager.FontProperties(size='smaller'))
    
    xticks(arange(12), month_list)
    
    ylim(10,37)
    xlim(-1,15)
    
    ylabel("in degree Celcius")
    
    grid(False)
    
    axes().xaxis.grid(True, color=(0.8,0.8,0.8), linestyle="-", which='major')
    
    title("Average mean max temp of Australian Cities (2003)")
    webshow("temp_2003.png")


def webshow( img ):
    savefig( img, dpi=70 )
    print 'Content-Type: text/html\n'
    print '<img width="500" size="400" src="'+img+'" />'
    
main()
