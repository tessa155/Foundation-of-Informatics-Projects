Group number : WED_10_5
Group members : Tessa(Hyeri) Song(597952), Martin(657605), Yash Narwal(612840)

The formation of the web application is quite different to the one shown in the presentation since we made a lot of alternations to css files.

1) To display the webpage, serve display_explanation.py which is connected to action_pivot.py.

2) All the graphs were produced by matplotlib and the scripts are as follow.
   1. solar_versus_rainfall.py 
   2. solar_versus_temp.py
   3. temp_2003
   4. temp_2004
   5. carins_temp

3) 5 XHTML files were designed to show each hypothesis,
   which are linked to display.py (the main page of this web application).
