from form import display_form
import cgitb; cgitb.enable()

def xhtml_chunk(title):
    print '''
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" id="display_hypothesis">
<head><meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<title>%s</title>
<link rel="stylesheet" href="css_file/decoration.css" type="text/css" media="screen" charset="utf-8" />
</head><body>
''' % title
    
def display_page():
    xhtml_chunk('Hypothesis')
    display_body()
    print '</html>'

    
def display_body():
    print '<div id="hypothesis_1">'
    print '<h1 id="header">Please Choose the hypothesis!</h1>' 
    print '<a href="deduction_1.html" title="Solar vs Temperature"><div><h1>0</h1></div></a>'   
    print '<a href="deduction_2.html" title="Solar vs Rainfall"><div><h1>1</h1></div></a>'   
    print '<a href="deduction_3.html" title="The hottest city"><div><h1>2</h1></div></a>'   
    print '<a href="deduction_4.html" title="The national wide drought in 2002"><div><h1>3</h1></div></a>'   
    print '<a href="deduction_5.html" title="Increasing temperature in Cairns"><div><h1>4</h1></div></a>'   
    print '<br />' 
    print '<br />'
    print '<h2><a href="display_explanation.py">Please click here to return to the previous page</a></h2>'  
    print '</div>'
    print '</body>'
    
def main ():
    print 'Content-Type: text/html\n'
    display_page()
    
main() 
