########################################################################################
#
#    This code is for the 3rd deduction, 2nd part of phase 2, of group WED_10_5, which
#    is about the drought in 2002 in Australia nationwide
#
########################################################################################


import os, sys
os.dup2(2,3)
stderr = os.fdopen(2,'a')
stderr.close()
import matplotlib
matplotlib.use('Agg')
from pylab import *
os.dup2(3,2)
sys.__stderr__ = sys.stderr = os.fdopen(2,'a')

import urllib
import csv
import cgi

from util import (city_list, year_list)

def open_files():
    data_list = []

    for csvfile in city_list:
        fopen = open('csv_file/'+csvfile+'.csv','r')
        data_list.append(list(csv.reader(fopen)))
    return data_list

def extract_info(data_list, column):
    info_list = []
    
    for data in data_list:
        info = []
        for i in range(16,27):
            info.append(data[i][column])
        info_list.append(info)

    return info_list    
    

def main():
    
    data_list = open_files()
    rain_list = extract_info(data_list, 2)
    year_list_n = extract_info(data_list, 1)
    
    clf()
    i = 0
    for rain in rain_list:
        plot(year_list_n[i],rain, "-")
        i +=1

    legend(city_list, loc='lower right', numpoints=40,
           prop=matplotlib.font_manager.FontProperties(size='smaller'))  
      
    ylabel("rainfall")
    xlabel("year")
    
    xlim(1995,2009)
    
    title("Relationship of rainfall and time of 6 cities(1995 - 2005)")
    webshow("rain_time.png")


def webshow( img ):
    savefig( img, dpi=70 )
    print 'Content-Type: text/html\n'
    print '<img width="500" height="400" src="'+img+'" />'
    
main()

