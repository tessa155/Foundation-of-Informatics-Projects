import os, sys
os.dup2(2,3)
stderr = os.fdopen(2,'a')
stderr.close()
import matplotlib
matplotlib.use('Agg')
from pylab import *
os.dup2(3,2)
sys.__stderr__ = sys.stderr = os.fdopen(2,'a')

import urllib
import csv
import cgi
from util import (city_list, year_list)

def open_files():
    data_list = []

    for csvfile in city_list:
        fopen = open('csv_file/'+csvfile+'.csv','r')
        data_list.append(list(csv.reader(fopen)))
    return data_list

def main():
    year_range = range(1980,2013)
    data_list = open_files()
    carins_data = data_list[4];
    
    temp_list = []
    
    for i in range(1,34):
        temp_list.append(carins_data[i][3])
    
    clf()

    plot(temp_list)
    
    xlim(-1,33)
    ylim(28,30.5)
    
    ylabel("temperature")
    
    xticks(range(0,33),year_range,rotation='vertical')
    
    title("Increasing temperature of Cairns(1980 - 2012)")
    webshow("cairns_temp.png")


def webshow( img ):
    savefig( img, dpi=70 )
    print 'Content-Type: text/html\n'
    print '<img width="500" height="400" src="'+img+'" />'
    
main()

