city_list = ['Melbourne','Sydney','Darwin','Adelaide','Cairns','Perth']
month_list = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
year_list = range(1980, 2013)

