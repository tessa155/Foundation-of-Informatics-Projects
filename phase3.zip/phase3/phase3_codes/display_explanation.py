from form import display_form
import cgitb; cgitb.enable()

def xhtml_chunk(title):
    print '''
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" id="display_explanation">
<head><meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<title>%s</title>
<link rel="stylesheet" href="css_file/decoration.css" type="text/css" media="screen" charset="utf-8" />
</head><body>
''' % title
    

def display_page():
    xhtml_chunk('Web Application')
    display_body()
    print '</html>'

    
def display_body():
    print '<div id="part_1">'
    print '<h1 id="header">Web Application</h1>'
    print '</div>'
    print '<div id="part_2">'
    print '<a href="display_hypothesis.py" title="Click here to see the hypothesises"><div id="hypothesis"><p class="selector">Hypothesis</p></div></a>'
    print '<a href="display_form.py" title="Click here to see the pivot table"><div id="pivot"><p class="selector">Pivot Table</p></div></a>'
    print '</div>'
    print '<div id="general_explanation">'
    print '<h1 id="head_1">General Explanation</h1>'
    print '<h3>Our group has investigated the pattern, trend and features of the weather of Australian over the last 30 years, from 1980 to 2012. 6 representative cities have been chosen for this investigation, which are Melbourne, Sydney, Darwin, Adelaide, Cairns and Perth and basically 3 kinds of numerical values have been examined.</h3>'
    print '<h3>The first one is the total of rainfall for the whole year and the unit is mm.</h3>'
    print '<h3>The second one is the average of monthly mean-max temperature for a year and the monthly mean maximum temperature is the average of all available daily maxima for the month. The unit is Celsius.</h3>'
    print '<h3>The last one is the average of monthly mean-daily solar exposure for a year. The monthly mean-daily solar exposure means the average of all available daily exposure for the month and the daily global exposure is the total solar energy for a day falling on a horizontal surface.</h3>'
    print '<h3>The unit is MJ m-2</h3>'
    print '</div>'
    print '</body>'
    
def main ():
    print 'Content-Type: text/html\n'
    display_page()
    
main() 
